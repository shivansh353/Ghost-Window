using System;
using System.Drawing;
using System.Windows.Forms;

namespace GhostWindow.Services
{
    public class TrayManager : IDisposable
    {
        private NotifyIcon? _notifyIcon;
        private bool _isDisposed;

        public event EventHandler? ShowWindowRequested;
        public event EventHandler? GhostToggleRequested;
        public event EventHandler? DetachRequested;
        public event EventHandler? ExitRequested;

        public void Initialize()
        {
            _notifyIcon = new NotifyIcon
            {
                Text = "GhostWindow - Window Transparency Controller",
                Icon = SystemIcons.Shield,
                Visible = true
            };

            var contextMenu = new ContextMenuStrip();
            var openItem = new ToolStripMenuItem("Show GhostWindow", null, (s, e) => ShowWindowRequested?.Invoke(this, EventArgs.Empty));
            var ghostItem = new ToolStripMenuItem("Toggle Ghost / Restore", null, (s, e) => GhostToggleRequested?.Invoke(this, EventArgs.Empty));
            var detachItem = new ToolStripMenuItem("Detach Window", null, (s, e) => DetachRequested?.Invoke(this, EventArgs.Empty));
            var sep = new ToolStripSeparator();
            var exitItem = new ToolStripMenuItem("Exit", null, (s, e) => ExitRequested?.Invoke(this, EventArgs.Empty));

            contextMenu.Items.Add(openItem);
            contextMenu.Items.Add(ghostItem);
            contextMenu.Items.Add(detachItem);
            contextMenu.Items.Add(sep);
            contextMenu.Items.Add(exitItem);

            _notifyIcon.ContextMenuStrip = contextMenu;
            _notifyIcon.DoubleClick += (s, e) => ShowWindowRequested?.Invoke(this, EventArgs.Empty);
        }

        public void UpdateTooltip(string message)
        {
            if (_notifyIcon != null)
            {
                string text = $"GhostWindow: {message}";
                if (text.Length > 63)
                    text = text.Substring(0, 60) + "...";
                _notifyIcon.Text = text;
            }
        }

        public void ShowNotification(string title, string text, ToolTipIcon icon = ToolTipIcon.Info)
        {
            _notifyIcon?.ShowBalloonTip(2000, title, text, icon);
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                if (_notifyIcon != null)
                {
                    _notifyIcon.Visible = false;
                    _notifyIcon.Dispose();
                    _notifyIcon = null;
                }
                _isDisposed = true;
            }
            GC.SuppressFinalize(this);
        }
    }
}
