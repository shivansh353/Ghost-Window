using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using GhostWindow.Native;

namespace GhostWindow.Services
{
    public class GlobalMouseHook : IDisposable
    {
        private IntPtr _hookId = IntPtr.Zero;
        private readonly Win32.LowLevelMouseProc _proc;
        private bool _isDisposed;

        private bool _isLeftDown;
        private bool _isRightDown;
        private long _lastGestureTime;
        private const long GestureCooldownMs = 500;

        public event EventHandler? BothButtonsScrollDownDetected;

        public bool IsEnabled { get; set; } = true;
        public Func<bool>? ShouldProcessShortcuts { get; set; }

        public GlobalMouseHook()
        {
            _proc = HookCallback;
            InstallHook();
        }

        private void InstallHook()
        {
            using var curProcess = Process.GetCurrentProcess();
            using var curModule = curProcess.MainModule;
            IntPtr moduleHandle = Win32.GetModuleHandle(curModule?.ModuleName);
            _hookId = Win32.SetWindowsHookEx(Win32.WH_MOUSE_LL, _proc, moduleHandle, 0);
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && IsEnabled)
            {
                int msg = wParam.ToInt32();

                if (msg == (int)Win32.WM_LBUTTONDOWN)
                {
                    _isLeftDown = true;
                }
                else if (msg == (int)Win32.WM_LBUTTONUP)
                {
                    _isLeftDown = false;
                }
                else if (msg == (int)Win32.WM_RBUTTONDOWN)
                {
                    _isRightDown = true;
                }
                else if (msg == (int)Win32.WM_RBUTTONUP)
                {
                    _isRightDown = false;
                }
                else if (msg == (int)Win32.WM_MOUSEWHEEL)
                {
                    bool canProcess = ShouldProcessShortcuts == null || ShouldProcessShortcuts();
                    if (canProcess)
                    {
                        // Check if both mouse buttons are pressed (state tracking + GetAsyncKeyState for high accuracy)
                        bool leftPressed = _isLeftDown || (Win32.GetAsyncKeyState(Win32.VK_LBUTTON) & 0x8000) != 0;
                        bool rightPressed = _isRightDown || (Win32.GetAsyncKeyState(Win32.VK_RBUTTON) & 0x8000) != 0;

                        if (leftPressed && rightPressed)
                        {
                            var hookStruct = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);
                            short delta = unchecked((short)((hookStruct.mouseData >> 16) & 0xFFFF));

                            // Negative delta indicates mouse wheel scroll down (towards user)
                            if (delta < 0)
                            {
                                long now = Environment.TickCount64;
                                if (now - _lastGestureTime >= GestureCooldownMs)
                                {
                                    _lastGestureTime = now;
                                    BothButtonsScrollDownDetected?.Invoke(this, EventArgs.Empty);
                                }
                            }
                        }
                    }
                }
            }

            return Win32.CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                if (_hookId != IntPtr.Zero)
                {
                    Win32.UnhookWindowsHookEx(_hookId);
                    _hookId = IntPtr.Zero;
                }
                _isDisposed = true;
            }
            GC.SuppressFinalize(this);
        }

        ~GlobalMouseHook()
        {
            Dispose();
        }
    }
}
