using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using GhostWindow.Native;

namespace GhostWindow.Services
{
    public class ContactPoint
    {
        public int Id { get; set; }
        public int StartX { get; set; }
        public int StartY { get; set; }
        public int CurrentX { get; set; }
        public int CurrentY { get; set; }
        public long StartTime { get; set; }
        public long LastUpdateTime { get; set; }
        public bool IsActive { get; set; }
    }

    public class PrecisionTouchpadService : IDisposable
    {
        public event EventHandler? FourFingerSwipeDownDetected;
        public event Action<string>? LogMessage;

        private IntPtr _hwnd;
        private HwndSource? _hwndSource;
        private bool _isDisposed;
        private readonly Stopwatch _stopwatch = Stopwatch.StartNew();

        // Contact tracking for precision multi-touch
        private readonly ConcurrentDictionary<int, ContactPoint> _contacts = new();
        private long _lastGestureTriggerTime = 0;
        private const long GestureCooldownMs = 800; // Prevent duplicate triggers within 800ms

        public bool IsRegistered { get; private set; }

        public void Initialize(IntPtr windowHandle)
        {
            _hwnd = windowHandle;
            _hwndSource = HwndSource.FromHwnd(_hwnd);
            _hwndSource?.AddHook(WndProc);

            RegisterTouchpadRawInput();
        }

        private void RegisterTouchpadRawInput()
        {
            try
            {
                var devices = new RawInput.RAWINPUTDEVICE[]
                {
                    // Precision Touchpad (Digitizer Usage Page 0x0D, Touch Pad Usage 0x05)
                    new RawInput.RAWINPUTDEVICE
                    {
                        usUsagePage = RawInput.HID_USAGE_PAGE_DIGITIZER,
                        usUsage = RawInput.HID_USAGE_DIGITIZER_TOUCHPAD,
                        dwFlags = RawInput.RIDEV_INPUTSINK | RawInput.RIDEV_DEVNOTIFY,
                        hwndTarget = _hwnd
                    },
                    // Touchscreen / multi-touch digitizer fallback (Usage Page 0x0D, Usage 0x04)
                    new RawInput.RAWINPUTDEVICE
                    {
                        usUsagePage = RawInput.HID_USAGE_PAGE_DIGITIZER,
                        usUsage = RawInput.HID_USAGE_DIGITIZER_TOUCHSCREEN,
                        dwFlags = RawInput.RIDEV_INPUTSINK | RawInput.RIDEV_DEVNOTIFY,
                        hwndTarget = _hwnd
                    }
                };

                bool success = RawInput.RegisterRawInputDevices(devices, (uint)devices.Length, (uint)Marshal.SizeOf<RawInput.RAWINPUTDEVICE>());
                IsRegistered = success;

                if (success)
                {
                    LogMessage?.Invoke("Precision Touchpad Raw Input registered successfully.");
                }
                else
                {
                    int err = Marshal.GetLastWin32Error();
                    LogMessage?.Invoke($"RawInput registration returned error code: {err}");
                }
            }
            catch (Exception ex)
            {
                LogMessage?.Invoke($"Failed to register Touchpad RawInput: {ex.Message}");
            }
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == (int)Win32.WM_INPUT)
            {
                ProcessRawInput(lParam);
            }

            return IntPtr.Zero;
        }

        private unsafe void ProcessRawInput(IntPtr hRawInput)
        {
            uint size = 0;
            uint headerSize = (uint)Marshal.SizeOf<RawInput.RAWINPUTHEADER>();

            // Get required size
            if (RawInput.GetRawInputData(hRawInput, RawInput.RID_INPUT, IntPtr.Zero, ref size, headerSize) != 0 || size == 0)
                return;

            IntPtr buffer = Marshal.AllocHGlobal((int)size);
            try
            {
                if (RawInput.GetRawInputData(hRawInput, RawInput.RID_INPUT, buffer, ref size, headerSize) == size)
                {
                    var header = Marshal.PtrToStructure<RawInput.RAWINPUTHEADER>(buffer);
                    if (header.dwType == RawInput.RIM_TYPEHID)
                    {
                        IntPtr rawHidPtr = IntPtr.Add(buffer, (int)headerSize);
                        var rawHid = Marshal.PtrToStructure<RawInput.RAWHID>(rawHidPtr);

                        int hidHeaderSize = Marshal.SizeOf<RawInput.RAWHID>();
                        IntPtr rawDataPtr = IntPtr.Add(rawHidPtr, hidHeaderSize);
                        int dataLength = (int)(rawHid.dwSizeHid * rawHid.dwCount);

                        if (dataLength > 0)
                        {
                            byte[] data = new byte[dataLength];
                            Marshal.Copy(rawDataPtr, data, 0, dataLength);
                            ParseHidTouchpadReport(data);
                        }
                    }
                }
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
        }

        private void ParseHidTouchpadReport(byte[] report)
        {
            long now = _stopwatch.ElapsedMilliseconds;

            // Precision touchpad HID reports typically include a report ID, contact count,
            // and an array of contact records (Contact ID, Tip Switch, Confidence, X, Y).
            // A typical PTP contact record is 5-8 bytes long.
            if (report.Length < 6)
                return;

            // Heuristic detection: extract potential contact pairs (X, Y, ContactID)
            int potentialContactsCount = 0;
            var currentActiveContacts = new List<(int id, int x, int y)>();

            // Parse contact blocks
            for (int i = 1; i + 4 < report.Length; i += 5)
            {
                byte status = report[i];
                bool tipSwitch = (status & 0x01) != 0; // Finger in contact
                int contactId = (status >> 1) & 0x0F;

                if (tipSwitch)
                {
                    int x = report[i + 1] | ((report[i + 2] & 0x0F) << 8);
                    int y = ((report[i + 2] >> 4) & 0x0F) | (report[i + 3] << 4);

                    currentActiveContacts.Add((contactId, x, y));
                    potentialContactsCount++;
                }
            }

            // Also check report length for 4-finger contact signatures
            if (currentActiveContacts.Count >= 4 || report.Length >= 20)
            {
                // Update contact tracking
                foreach (var c in currentActiveContacts)
                {
                    _contacts.AddOrUpdate(c.id,
                        id => new ContactPoint
                        {
                            Id = id,
                            StartX = c.x,
                            StartY = c.y,
                            CurrentX = c.x,
                            CurrentY = c.y,
                            StartTime = now,
                            LastUpdateTime = now,
                            IsActive = true
                        },
                        (id, existing) =>
                        {
                            existing.CurrentX = c.x;
                            existing.CurrentY = c.y;
                            existing.LastUpdateTime = now;
                            existing.IsActive = true;
                            return existing;
                        });
                }

                // Check swipe down gesture criteria
                EvaluateGesture(now);
            }

            // Cleanup stale contacts (> 400ms without update)
            foreach (var kvp in _contacts)
            {
                if (now - kvp.Value.LastUpdateTime > 400)
                {
                    _contacts.TryRemove(kvp.Key, out _);
                }
            }
        }

        private void EvaluateGesture(long now)
        {
            if (now - _lastGestureTriggerTime < GestureCooldownMs)
                return;

            var activeList = _contacts.Values.Where(c => c.IsActive && (now - c.LastUpdateTime < 300)).ToList();

            if (activeList.Count >= 4)
            {
                // Check if the contacts have moved downward (delta Y > threshold)
                int downwardMovingCount = 0;
                foreach (var contact in activeList)
                {
                    int deltaY = contact.CurrentY - contact.StartY;
                    long duration = now - contact.StartTime;

                    // Positive delta Y is downward motion in standard screen coordinates
                    if (deltaY > 30 && duration < 700)
                    {
                        downwardMovingCount++;
                    }
                }

                if (downwardMovingCount >= 3) // At least 3 or 4 fingers moving downward
                {
                    _lastGestureTriggerTime = now;
                    _contacts.Clear();
                    TriggerGesture();
                }
            }
        }

        public void TriggerGesture()
        {
            LogMessage?.Invoke("4-Finger Downward Swipe gesture triggered!");
            FourFingerSwipeDownDetected?.Invoke(this, EventArgs.Empty);
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                _hwndSource?.RemoveHook(WndProc);
                _isDisposed = true;
            }
            GC.SuppressFinalize(this);
        }
    }
}
