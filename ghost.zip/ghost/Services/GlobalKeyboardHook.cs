using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using GhostWindow.Native;

namespace GhostWindow.Services
{
    public class GlobalKeyboardHook : IDisposable
    {
        private IntPtr _hookId = IntPtr.Zero;
        private readonly Win32.LowLevelKeyboardProc _proc;
        private bool _isDisposed;

        public event EventHandler? RestoreRequested;
        public event EventHandler? CloseRequested;

        public bool IsEnabled { get; set; } = true;
        public Func<bool>? ShouldProcessShortcuts { get; set; }

        public GlobalKeyboardHook()
        {
            _proc = HookCallback;
            InstallHook();
        }

        private void InstallHook()
        {
            using var curProcess = Process.GetCurrentProcess();
            using var curModule = curProcess.MainModule;
            IntPtr moduleHandle = Win32.GetModuleHandle(curModule?.ModuleName);
            _hookId = Win32.SetWindowsHookEx(Win32.WH_KEYBOARD_LL, _proc, moduleHandle, 0);
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && IsEnabled)
            {
                int msg = wParam.ToInt32();
                if (msg == Win32.WM_KEYDOWN || msg == Win32.WM_SYSKEYDOWN)
                {
                    var hookStruct = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
                    uint vkCode = hookStruct.vkCode;

                    bool canProcess = ShouldProcessShortcuts == null || ShouldProcessShortcuts();

                    if (canProcess)
                    {
                        // '/' key (US OEM_2 or Numpad Divide)
                        if (vkCode == Win32.VK_OEM_2 || vkCode == Win32.VK_DIVIDE)
                        {
                            RestoreRequested?.Invoke(this, EventArgs.Empty);
                        }
                        // 'K' key (case insensitive vk code 0x4B)
                        else if (vkCode == Win32.VK_K)
                        {
                            CloseRequested?.Invoke(this, EventArgs.Empty);
                        }
                    }
                }
            }

            return Win32.CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        public void Dispose()
        {
            if (!_isDisposed)
            {
                if (_hookId != IntPtr.Zero)
                {
                    Win32.UnhookWindowsHookEx(_hookId);
                    _hookId = IntPtr.Zero;
                }
                _isDisposed = true;
            }
            GC.SuppressFinalize(this);
        }

        ~GlobalKeyboardHook()
        {
            Dispose();
        }
    }
}
