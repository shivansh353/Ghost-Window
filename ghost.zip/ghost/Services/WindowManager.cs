using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Threading;
using GhostWindow.Models;
using GhostWindow.Native;

namespace GhostWindow.Services
{
    public enum WindowStateStatus
    {
        Detached,
        AttachedNormal,
        AttachedTransparent
    }

    public class WindowManager
    {
        public WindowInfo? AttachedWindow { get; private set; }
        public WindowStateStatus CurrentStatus { get; private set; } = WindowStateStatus.Detached;

        public event EventHandler<WindowStateStatus>? StatusChanged;
        public event EventHandler<WindowInfo?>? AttachedWindowChanged;
        public event EventHandler? TargetWindowClosedExternally;

        private readonly DispatcherTimer _healthCheckTimer;

        public WindowManager()
        {
            _healthCheckTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(500)
            };
            _healthCheckTimer.Tick += OnHealthCheckTick;
        }

        public List<WindowInfo> EnumerateWindows()
        {
            var list = new List<WindowInfo>();

            Win32.EnumWindows((hWnd, lParam) =>
            {
                var win = WindowInfo.FromHandle(hWnd);
                if (win != null)
                {
                    list.Add(win);
                }
                return true;
            }, IntPtr.Zero);

            return list;
        }

        public bool Attach(WindowInfo window)
        {
            if (window == null || !Win32.IsWindow(window.Handle))
                return false;

            // If another window is already attached, detach it cleanly first
            if (AttachedWindow != null)
            {
                Detach();
            }

            // Capture initial window styles and layered attributes
            long currentExStyle = Win32.GetWindowLongPtr(window.Handle, Win32.GWL_EXSTYLE).ToInt64();
            window.OriginalExStyle = (IntPtr)currentExStyle;
            window.IsOriginallyLayered = (currentExStyle & Win32.WS_EX_LAYERED) != 0;

            if (window.IsOriginallyLayered)
            {
                if (Win32.GetLayeredWindowAttributes(window.Handle, out _, out byte currentAlpha, out _))
                {
                    window.OriginalAlpha = currentAlpha;
                }
                else
                {
                    window.OriginalAlpha = 255;
                }
            }
            else
            {
                window.OriginalAlpha = 255;
            }

            AttachedWindow = window;
            CurrentStatus = WindowStateStatus.AttachedNormal;
            _healthCheckTimer.Start();

            AttachedWindowChanged?.Invoke(this, AttachedWindow);
            StatusChanged?.Invoke(this, CurrentStatus);

            return true;
        }

        public bool SetGhostTransparency(bool transparent)
        {
            if (AttachedWindow == null || !Win32.IsWindow(AttachedWindow.Handle))
                return false;

            IntPtr hWnd = AttachedWindow.Handle;

            if (transparent)
            {
                // Make 100% transparent
                long currentExStyle = Win32.GetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE).ToInt64();
                long newExStyle = currentExStyle | Win32.WS_EX_LAYERED | Win32.WS_EX_TRANSPARENT;

                Win32.SetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE, (IntPtr)newExStyle);
                Win32.SetLayeredWindowAttributes(hWnd, 0, 0, Win32.LWA_ALPHA);

                AttachedWindow.IsGhosted = true;
                CurrentStatus = WindowStateStatus.AttachedTransparent;
            }
            else
            {
                // Restore to original opacity and styles
                if (AttachedWindow.IsOriginallyLayered)
                {
                    // Restore original layered alpha
                    Win32.SetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE, AttachedWindow.OriginalExStyle);
                    Win32.SetLayeredWindowAttributes(hWnd, 0, AttachedWindow.OriginalAlpha, Win32.LWA_ALPHA);
                }
                else
                {
                    // First set alpha to 255
                    Win32.SetLayeredWindowAttributes(hWnd, 0, 255, Win32.LWA_ALPHA);
                    // Remove WS_EX_LAYERED and WS_EX_TRANSPARENT
                    long currentExStyle = Win32.GetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE).ToInt64();
                    long cleanExStyle = currentExStyle & ~Win32.WS_EX_LAYERED & ~Win32.WS_EX_TRANSPARENT;
                    Win32.SetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE, (IntPtr)cleanExStyle);
                }

                AttachedWindow.IsGhosted = false;
                CurrentStatus = WindowStateStatus.AttachedNormal;
            }

            StatusChanged?.Invoke(this, CurrentStatus);
            return true;
        }

        public void CloseAttachedWindow()
        {
            if (AttachedWindow == null)
                return;

            IntPtr hWnd = AttachedWindow.Handle;

            // First restore visibility briefly if needed or directly send WM_CLOSE
            if (Win32.IsWindow(hWnd))
            {
                try
                {
                    Win32.PostMessage(hWnd, Win32.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                }
                catch
                {
                    // Ignore errors during close post
                }
            }

            Detach();
        }

        public void Detach()
        {
            _healthCheckTimer.Stop();

            if (AttachedWindow != null && Win32.IsWindow(AttachedWindow.Handle))
            {
                if (AttachedWindow.IsGhosted)
                {
                    SetGhostTransparency(false);
                }
            }

            AttachedWindow = null;
            CurrentStatus = WindowStateStatus.Detached;

            AttachedWindowChanged?.Invoke(this, null);
            StatusChanged?.Invoke(this, CurrentStatus);
        }

        private void OnHealthCheckTick(object? sender, EventArgs e)
        {
            if (AttachedWindow != null)
            {
                if (!Win32.IsWindow(AttachedWindow.Handle))
                {
                    // Target window was closed externally
                    _healthCheckTimer.Stop();
                    AttachedWindow = null;
                    CurrentStatus = WindowStateStatus.Detached;

                    AttachedWindowChanged?.Invoke(this, null);
                    StatusChanged?.Invoke(this, CurrentStatus);
                    TargetWindowClosedExternally?.Invoke(this, EventArgs.Empty);
                }
            }
        }
    }
}
