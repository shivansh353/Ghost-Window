using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using GhostWindow.Models;
using GhostWindow.Services;

namespace GhostWindow
{
    public partial class MainWindow : Window
    {
        private readonly WindowManager _windowManager;
        private readonly GlobalKeyboardHook _keyboardHook;
        private readonly GlobalMouseHook _mouseHook;
        private readonly PrecisionTouchpadService _touchpadService;
        private readonly TrayManager _trayManager;

        private bool _isClosingForReal;

        public MainWindow()
        {
            InitializeComponent();

            _windowManager = new WindowManager();
            _keyboardHook = new GlobalKeyboardHook();
            _mouseHook = new GlobalMouseHook();
            _touchpadService = new PrecisionTouchpadService();
            _trayManager = new TrayManager();

            // Window manager events
            _windowManager.StatusChanged += OnWindowManagerStatusChanged;
            _windowManager.AttachedWindowChanged += OnAttachedWindowChanged;
            _windowManager.TargetWindowClosedExternally += OnTargetWindowClosedExternally;

            // Keyboard hook events
            _keyboardHook.ShouldProcessShortcuts = () => _windowManager.AttachedWindow != null;
            _keyboardHook.RestoreRequested += (s, e) => Dispatcher.Invoke(HandleRestoreRequested);
            _keyboardHook.CloseRequested += (s, e) => Dispatcher.Invoke(HandleCloseRequested);

            // Mouse hook events (Both buttons clicked + scroll down)
            _mouseHook.ShouldProcessShortcuts = () => _windowManager.AttachedWindow != null;
            _mouseHook.BothButtonsScrollDownDetected += (s, e) => Dispatcher.Invoke(HandleMouseGestureSwipeDown);

            // Precision touchpad events
            _touchpadService.FourFingerSwipeDownDetected += (s, e) => Dispatcher.Invoke(HandleTouchpadSwipeDown);

            // Tray icon events
            _trayManager.ShowWindowRequested += (s, e) => Dispatcher.Invoke(ShowWindowFromTray);
            _trayManager.GhostToggleRequested += (s, e) => Dispatcher.Invoke(ToggleGhostState);
            _trayManager.DetachRequested += (s, e) => Dispatcher.Invoke(() => _windowManager.Detach());
            _trayManager.ExitRequested += (s, e) => Dispatcher.Invoke(ExitApplication);

            Loaded += MainWindow_Loaded;
            Closing += MainWindow_Closing;
            StateChanged += MainWindow_StateChanged;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            _touchpadService.Initialize(hwnd);
            _trayManager.Initialize();

            RefreshWindowsList();
            UpdateUIState();
        }

        private void MainWindow_StateChanged(object? sender, EventArgs e)
        {
            if (WindowState == WindowState.Minimized)
            {
                // Optional: hide to tray when minimized
                Hide();
                _trayManager.ShowNotification("GhostWindow", "Running in system tray. Double-click tray icon to restore.");
            }
        }

        private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_isClosingForReal)
            {
                // Minimize to system tray instead of exiting immediately
                e.Cancel = true;
                Hide();
                _trayManager.ShowNotification("GhostWindow", "Minimized to tray. Use tray menu to Exit.");
            }
            else
            {
                // Clean up all resources
                _windowManager.Detach();
                _keyboardHook.Dispose();
                _mouseHook.Dispose();
                _touchpadService.Dispose();
                _trayManager.Dispose();
            }
        }

        private void ExitApplication()
        {
            _isClosingForReal = true;
            Close();
            Application.Current.Shutdown();
        }

        private void ShowWindowFromTray()
        {
            Show();
            WindowState = WindowState.Normal;
            Activate();
            BringIntoView();
        }

        private void RefreshWindowsList()
        {
            var windows = _windowManager.EnumerateWindows();
            LstWindows.ItemsSource = windows;
        }

        private void UpdateUIState()
        {
            var status = _windowManager.CurrentStatus;
            var attached = _windowManager.AttachedWindow;

            switch (status)
            {
                case WindowStateStatus.Detached:
                    TxtStatus.Text = "DETACHED";
                    TxtStatus.Foreground = (Brush)FindResource("TextMuted");
                    StatusIndicatorDot.Fill = (Brush)FindResource("TextMuted");
                    StatusBadge.Background = new SolidColorBrush(Color.FromArgb(255, 35, 35, 40));

                    TxtAttachedTitle.Text = "No window attached";
                    TxtAttachedProcess.Text = "Select an open window below to begin";
                    ImgAttachedIcon.Source = null;

                    BtnGhostToggle.IsEnabled = false;
                    BtnGhostToggle.Content = "Make Transparent";
                    BtnDetach.IsEnabled = false;
                    BtnCloseTarget.IsEnabled = false;

                    _trayManager.UpdateTooltip("Detached");
                    break;

                case WindowStateStatus.AttachedNormal:
                    TxtStatus.Text = "NORMAL";
                    TxtStatus.Foreground = (Brush)FindResource("SuccessGreen");
                    StatusIndicatorDot.Fill = (Brush)FindResource("SuccessGreen");
                    StatusBadge.Background = new SolidColorBrush(Color.FromArgb(40, 0, 230, 118));

                    if (attached != null)
                    {
                        TxtAttachedTitle.Text = attached.DisplayName;
                        TxtAttachedProcess.Text = $"{attached.ProcessName} (PID: {attached.ProcessId})";
                        ImgAttachedIcon.Source = attached.Icon;
                    }

                    BtnGhostToggle.IsEnabled = true;
                    BtnGhostToggle.Content = "Make Transparent";
                    BtnDetach.IsEnabled = true;
                    BtnCloseTarget.IsEnabled = true;

                    _trayManager.UpdateTooltip($"Attached: {attached?.DisplayName} [Normal]");
                    break;

                case WindowStateStatus.AttachedTransparent:
                    TxtStatus.Text = "TRANSPARENT";
                    TxtStatus.Foreground = (Brush)FindResource("GhostCyan");
                    StatusIndicatorDot.Fill = (Brush)FindResource("GhostCyan");
                    StatusBadge.Background = new SolidColorBrush(Color.FromArgb(40, 0, 229, 255));

                    if (attached != null)
                    {
                        TxtAttachedTitle.Text = attached.DisplayName;
                        TxtAttachedProcess.Text = $"{attached.ProcessName} (PID: {attached.ProcessId})";
                        ImgAttachedIcon.Source = attached.Icon;
                    }

                    BtnGhostToggle.IsEnabled = true;
                    BtnGhostToggle.Content = "Restore ( / )";
                    BtnDetach.IsEnabled = true;
                    BtnCloseTarget.IsEnabled = true;

                    _trayManager.UpdateTooltip($"Attached: {attached?.DisplayName} [Transparent]");
                    break;
            }
        }

        private void HandleTouchpadSwipeDown()
        {
            if (_windowManager.AttachedWindow != null)
            {
                _windowManager.SetGhostTransparency(true);
            }
        }

        private void HandleMouseGestureSwipeDown()
        {
            if (_windowManager.AttachedWindow != null)
            {
                _windowManager.SetGhostTransparency(true);
            }
        }

        private void HandleRestoreRequested()
        {
            if (_windowManager.AttachedWindow != null)
            {
                _windowManager.SetGhostTransparency(false);
            }
        }

        private void HandleCloseRequested()
        {
            // Close attached target window and detach. GhostWindow stays running!
            if (_windowManager.AttachedWindow != null)
            {
                _windowManager.CloseAttachedWindow();
            }
        }

        private void ToggleGhostState()
        {
            if (_windowManager.AttachedWindow != null)
            {
                if (_windowManager.CurrentStatus == WindowStateStatus.AttachedTransparent)
                    _windowManager.SetGhostTransparency(false);
                else
                    _windowManager.SetGhostTransparency(true);
            }
        }

        private void OnWindowManagerStatusChanged(object? sender, WindowStateStatus status)
        {
            UpdateUIState();
        }

        private void OnAttachedWindowChanged(object? sender, WindowInfo? window)
        {
            UpdateUIState();
        }

        private void OnTargetWindowClosedExternally(object? sender, EventArgs e)
        {
            RefreshWindowsList();
            UpdateUIState();
        }

        private void BtnRefreshList_Click(object sender, RoutedEventArgs e)
        {
            RefreshWindowsList();
        }

        private void LstWindows_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Optional item selection preview
        }

        private void LstWindows_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (LstWindows.SelectedItem is WindowInfo selected)
            {
                _windowManager.Attach(selected);
            }
        }

        private void BtnAttachItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is WindowInfo win)
            {
                _windowManager.Attach(win);
            }
        }

        private void BtnGhostToggle_Click(object sender, RoutedEventArgs e)
        {
            ToggleGhostState();
        }

        private void BtnDetach_Click(object sender, RoutedEventArgs e)
        {
            _windowManager.Detach();
        }

        private void BtnCloseTarget_Click(object sender, RoutedEventArgs e)
        {
            HandleCloseRequested();
        }

        private void BtnMinimizeTray_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
    }
}
