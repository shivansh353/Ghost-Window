# GhostWindow 👻

**GhostWindow** is a sleek, modern Windows 11 desktop application designed to control the transparency and lifecycle of any open application window (Chrome, YouTube, WhatsApp, File Explorer, etc.) using laptop Precision Touchpad multi-finger gestures and global keyboard shortcuts.

---

## ✨ Features

- **Attach to Any Window**: Select and attach to any top-level Windows application (Chrome, VS Code, File Explorer, WhatsApp, etc.).
- **Dual Gesture Support**:
  - **Laptop Touchpad**: `4-Finger Downward Swipe`
  - **Desktop / PC Mouse**: `Click both mouse buttons (Left + Right) and scroll down`
  - Instantly makes the attached window **100% transparent** while keeping it active in the background.
- **Global Restore (`/` key)**: Instantly restores the attached window back to its original opacity.
- **Global Close & Detach (`K` key)**: Closes the target window and cleanly detaches/clears the state (GhostWindow itself never closes).
- **Windows 11 Fluent Dark UI**: Polished dark theme with live glowing status indicators, icon extraction, and quick actions.
- **System Tray Mode**: Minimizes cleanly to the Windows notification tray with right-click actions and notifications.
- **Robust Win32 Interop**: Uses `SetLayeredWindowAttributes`, `GetLayeredWindowAttributes`, `SetWindowLongPtr`, `RegisterRawInputDevices`, and low-level mouse & keyboard hooks.
- **Edge Case Protection**: Automatically detects when a target window is closed externally, minimized, or detached, safely restoring states without leaving orphan transparent windows.

---

## 🎮 Shortcut & Gesture Guide

| Action | Input / Trigger | Description |
|---|---|---|
| **Ghost (100% Transparent)** | `4-finger swipe ↓` (Touchpad) <br/> **or** `Left + Right Click + Scroll ↓` (Mouse) | Makes the attached window completely transparent while remaining active. |
| **Restore Opacity** | Press `/` | Restores the attached window back to its original visibility. |
| **Close & Detach** | Press `K` | Closes the target application and detaches from GhostWindow. |
| **Detach** | Click `[ Detach ]` in UI / Tray | Safely restores the window and detaches without closing it. |

---

## 🚀 How to Run

### Requirements
- Windows 10 / Windows 11 (64-bit)
- .NET 8.0 Desktop Runtime or SDK

### Build & Launch
```powershell
# From the project directory
dotnet run -c Release
```

Or build a standalone release executable:
```powershell
dotnet publish -c Release -r win-x64 --self-contained false -o ./publish
```

---

## 🧪 Testing Checklist

1. Open **Google Chrome** (or any application like File Explorer).
2. Launch **GhostWindow**.
3. Select the Chrome window in the list and click **Attach** (or double-click it).
4. Perform a **4-finger downward swipe** on your laptop's Precision Touchpad:
   - Verify Chrome becomes **100% transparent** while still active.
5. Press `/` anywhere globally:
   - Verify Chrome becomes visible again.
6. Trigger the 4-finger downward swipe again to make it transparent.
7. Press `K` anywhere globally:
   - Verify Chrome closes.
   - Verify GhostWindow updates status to `DETACHED` and remains running.
