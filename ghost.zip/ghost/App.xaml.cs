using System;
using System.Windows;

namespace GhostWindow
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            AppDomain.CurrentDomain.UnhandledException += (s, args) =>
            {
                if (args.ExceptionObject is Exception ex)
                {
                    MessageBox.Show($"Unexpected error: {ex.Message}", "GhostWindow", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };
        }
    }
}
