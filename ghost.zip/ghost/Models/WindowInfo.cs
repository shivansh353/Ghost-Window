using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media.Imaging;
using GhostWindow.Native;

namespace GhostWindow.Models
{
    public class WindowInfo
    {
        public IntPtr Handle { get; set; }
        public string Title { get; set; } = string.Empty;
        public string ProcessName { get; set; } = string.Empty;
        public int ProcessId { get; set; }
        public BitmapSource? Icon { get; set; }
        public IntPtr OriginalExStyle { get; set; }
        public byte OriginalAlpha { get; set; } = 255;
        public bool IsOriginallyLayered { get; set; }
        public bool IsGhosted { get; set; }

        public string DisplayName => string.IsNullOrWhiteSpace(Title) ? $"[{ProcessName}]" : Title;

        public static WindowInfo? FromHandle(IntPtr hWnd)
        {
            if (!Win32.IsWindow(hWnd) || !Win32.IsWindowVisible(hWnd))
                return null;

            int length = Win32.GetWindowTextLength(hWnd);
            if (length == 0)
                return null;

            StringBuilder sb = new StringBuilder(length + 1);
            Win32.GetWindowText(hWnd, sb, sb.Capacity);
            string title = sb.ToString();

            if (string.IsNullOrWhiteSpace(title))
                return null;

            // Check if window is cloaked (e.g. Windows 11 virtual desktops or suspended UWP)
            int cloaked = 0;
            Win32.DwmGetWindowAttribute(hWnd, Win32.DWMWA_CLOAKED, out cloaked, sizeof(int));
            if (cloaked != 0)
                return null;

            // Check if it's a tool window (unless it has app window style)
            long exStyle = Win32.GetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE).ToInt64();
            if ((exStyle & Win32.WS_EX_TOOLWINDOW) != 0 && (exStyle & Win32.WS_EX_APPWINDOW) == 0)
                return null;

            Win32.GetWindowThreadProcessId(hWnd, out uint processId);
            string processName = "Unknown";
            BitmapSource? icon = null;

            try
            {
                using var proc = Process.GetProcessById((int)processId);
                processName = proc.ProcessName;

                // Don't attach to GhostWindow itself
                if (processId == Environment.ProcessId || processName.Equals("GhostWindow", StringComparison.OrdinalIgnoreCase))
                    return null;

                // Attempt to get application icon
                icon = ExtractWindowIcon(hWnd, proc);
            }
            catch
            {
                // Access denied on some system processes
            }

            return new WindowInfo
            {
                Handle = hWnd,
                Title = title,
                ProcessName = processName,
                ProcessId = (int)processId,
                Icon = icon,
                OriginalExStyle = (IntPtr)exStyle,
                IsOriginallyLayered = (exStyle & Win32.WS_EX_LAYERED) != 0,
                IsGhosted = false
            };
        }

        private static BitmapSource? ExtractWindowIcon(IntPtr hWnd, Process proc)
        {
            try
            {
                IntPtr hIcon = Win32.SendMessage(hWnd, Win32.WM_GETICON, (IntPtr)Win32.ICON_SMALL2, IntPtr.Zero);
                if (hIcon == IntPtr.Zero)
                    hIcon = Win32.SendMessage(hWnd, Win32.WM_GETICON, (IntPtr)Win32.ICON_SMALL, IntPtr.Zero);
                if (hIcon == IntPtr.Zero)
                    hIcon = Win32.SendMessage(hWnd, Win32.WM_GETICON, (IntPtr)Win32.ICON_BIG, IntPtr.Zero);
                if (hIcon == IntPtr.Zero)
                    hIcon = Win32.GetClassLongPtr(hWnd, Win32.GCL_HICONSM);
                if (hIcon == IntPtr.Zero)
                    hIcon = Win32.GetClassLongPtr(hWnd, Win32.GCL_HICON);

                if (hIcon != IntPtr.Zero)
                {
                    var bs = Imaging.CreateBitmapSourceFromHIcon(
                        hIcon,
                        Int32Rect.Empty,
                        BitmapSizeOptions.FromEmptyOptions());
                    bs.Freeze();
                    return bs;
                }

                // Fallback to process main module file icon
                if (!string.IsNullOrEmpty(proc.MainModule?.FileName) && File.Exists(proc.MainModule.FileName))
                {
                    using var sysIcon = System.Drawing.Icon.ExtractAssociatedIcon(proc.MainModule.FileName);
                    if (sysIcon != null)
                    {
                        var bs = Imaging.CreateBitmapSourceFromHIcon(
                            sysIcon.Handle,
                            Int32Rect.Empty,
                            BitmapSizeOptions.FromEmptyOptions());
                        bs.Freeze();
                        return bs;
                    }
                }
            }
            catch
            {
                // Ignore icon extraction failure
            }

            return null;
        }
    }
}
